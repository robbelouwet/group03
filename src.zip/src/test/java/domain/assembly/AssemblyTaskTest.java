package domain.assembly;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class AssemblyTaskTest {

    @Test
    void finishTask() {
        var task = new AssemblyTask("TestTask", List.of("TestAction"));
        task.finishTask();
        assertTrue(task.isFinished());
    }
}
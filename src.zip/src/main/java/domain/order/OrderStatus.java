package domain.order;

public enum OrderStatus {
    Pending,
    Finished,
    OnAssemblyLine
}

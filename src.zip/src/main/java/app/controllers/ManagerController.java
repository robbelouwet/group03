package app.controllers;

import app.ui.interfaces.IManagerView;
import domain.assembly.AssemblyTask;
import domain.order.CarOrder;
import services.AssemblyManager;
import services.CarOrderManager;
import services.ManagerStore;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ManagerController {
    private final AssemblyManager assemblyManager;
    private final CarOrderManager carOrderManager;
    private final IManagerView ui;

    public ManagerController(IManagerView ui) {
        this.ui = ui;
        this.assemblyManager = ManagerStore.getInstance().getAssemblyLineManager();
        this.carOrderManager = ManagerStore.getInstance().getCarOrderManager();
    }

    public void showMainMenu() {
        List<CarOrder> pendingOrders = carOrderManager.getPendingOrders();
        List<CarOrder> simFinishedOrders = assemblyManager.getSimulatedOrders(carOrderManager.getPendingOrders());
        Map<String, List<String>> pendingTasks = convertToStringList(assemblyManager.getPendingTasks());
        Map<String, List<String>> finishedTasks = convertToStringList(assemblyManager.getFinishedTasks());
        ui.showOverview(
                pendingOrders.stream().map(CarOrder::toString).collect(Collectors.toList()),
                simFinishedOrders.stream().map(CarOrder::toString).collect(Collectors.toList()),
                pendingTasks,
                finishedTasks
        );
    }

    /**
     * This method converts the Map<String, List<AssemblyTask>> to Map<String, List<String>>
     * This is because the view can not know of domain elements
     */
    private Map<String, List<String>> convertToStringList(Map<String, List<AssemblyTask>> pendingTasks) {
        Map<String, List<String>> tasks = new HashMap<>();
        pendingTasks.forEach((k, v) -> tasks.put(k, v.stream().map(AssemblyTask::toString).collect(Collectors.toList())));
        return tasks;
    }

    public void advanceAssemblyLine(int timeSpent) {
        boolean success = assemblyManager.advance(timeSpent);
        if (!success) ui.showErrorMessage("Assembly line is blocked!");

        List<CarOrder> pendingOrders = carOrderManager.getPendingOrders();
        ui.showAssemblyLineStatusAfterMove(pendingOrders.stream().map(CarOrder::toString).collect(Collectors.toList()));
    }
}

package app;


import app.ui.AppTextView;
import services.ManagerStore;

public class Main {
    public static void main(String[] args) {
        // usually, you put this view on a graphical canvas or something,
        // since we don't have that here, just create and forget the view
        ManagerStore.getInstance().init();
        (new AppTextView()).start();
    }
}

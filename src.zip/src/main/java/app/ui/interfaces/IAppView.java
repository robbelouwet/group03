package app.ui.interfaces;

public interface IAppView {

    String showMenu();

    void start();
}
